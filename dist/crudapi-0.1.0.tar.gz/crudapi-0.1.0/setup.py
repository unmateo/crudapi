# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['crudapi', 'crudapi.core', 'crudapi.routers', 'crudapi.services']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy>=1.3.20,<2.0.0', 'fastapi>=0.61.1,<0.62.0']

setup_kwargs = {
    'name': 'crudapi',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Mateo Harfuch',
    'author_email': 'mharfuch@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
